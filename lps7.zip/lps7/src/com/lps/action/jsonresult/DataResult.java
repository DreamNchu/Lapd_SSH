package com.lps.action.jsonresult;

import com.lps.web.basicmsg.dto.BasicMsgProxyDto;

public interface DataResult {
	
	StringBuilder result = new StringBuilder();
	
	BasicMsgProxyDto basicMsg = new BasicMsgProxyDto();
	
//	String MSG= "msg";
	
//	Map<String , Object> map = new HashMap<>();
	
	/**
	 * 返回json数据结果
	 * @return
	 */
//	String getResult();
	
//	void setResult(String result);
	
//	void writeInResult(BasicMsgDto obj);
	
}
