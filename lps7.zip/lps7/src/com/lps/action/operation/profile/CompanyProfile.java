package com.lps.action.operation.profile;

import com.lps.action.basic.ActionSupportLps;

public class CompanyProfile extends ActionSupportLps{

	private static final long serialVersionUID = 1707550388716767524L; 
	
	@Override
	public String execute() throws Exception {
		return super.execute();
	}

}
