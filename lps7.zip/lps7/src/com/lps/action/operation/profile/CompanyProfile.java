package com.lps.action.operation.profile;

import com.opensymphony.xwork2.ActionSupport;

public class CompanyProfile extends ActionSupport{

	private static final long serialVersionUID = 1707550388716767524L; 
	
	@Override
	public String execute() throws Exception {
		return super.execute();
	}

}
