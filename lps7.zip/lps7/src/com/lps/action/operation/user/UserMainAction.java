package com.lps.action.operation.user;

import com.opensymphony.xwork2.ActionSupport;

public class UserMainAction extends ActionSupport{

	private static final long serialVersionUID = -4775687348126830431L;
	
	@Override

	public String execute() throws Exception {
		return SUCCESS;
	}

}
