package com.lps.action.operation.user;

import com.lps.action.basic.ActionSupportLps;

public class UserMainAction extends ActionSupportLps{

	private static final long serialVersionUID = -4775687348126830431L;
	
	@Override

	public String execute() throws Exception {
		return SUCCESS;
	}

}
