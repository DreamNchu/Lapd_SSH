package com.lps.action.operation.admin;

import com.opensymphony.xwork2.ActionSupport;

public class AdminMainAction extends ActionSupport{

	private static final long serialVersionUID = -9186252906906960574L;

	public String main(){
		return SUCCESS;
	}
	
}
