package com.lps.control.manage;

public class CreateOrderFailedException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public CreateOrderFailedException() {
		// TODO Auto-generated constructor stub
	}
	
	public CreateOrderFailedException(String msg) {
		super(msg);
	}

}
