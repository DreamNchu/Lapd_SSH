package com.lps.control.manage;

public class CreateOrderFailedException extends CreateFailedException {

	private static final long serialVersionUID = 1L;
	
	public CreateOrderFailedException() {
		
	}
	
	public CreateOrderFailedException(String msg) {
		super(msg);
	}

}
