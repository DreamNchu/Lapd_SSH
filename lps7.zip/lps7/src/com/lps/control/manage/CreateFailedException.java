package com.lps.control.manage;

public class CreateFailedException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public CreateFailedException() {
		// TODO Auto-generated constructor stub
	}
	
	public CreateFailedException(String msg) {
		super(msg);
	}

	
}
